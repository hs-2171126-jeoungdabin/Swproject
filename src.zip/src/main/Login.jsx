import React from "react";
import { Link } from "react-router-dom";
import './Login.css';

function Login(props) {
    return (
        <div className="LoginBox">
            <p>아이디
                <input id="Id" placeholder="아이디를 입력하시오" />
            </p>
            <p>비밀번호
                <input id="Passwd" type="password" placeholder="비밀번호를 입력하시오" />
            </p>
            <button id='login'>로그인하기</button>
            <button id='join'>회원가입하기</button>
            <p>
                <Link to="/forgot-password">비밀번호를 잊으셨습니까?</Link>
            </p>
        </div>
    );
}

export default Login;
