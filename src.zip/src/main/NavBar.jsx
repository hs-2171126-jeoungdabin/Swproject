// src/components/NavBar.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import './NavBar.css';
import Login from './Login'

const NavBar = () => {
  return (
    <div className="navbar">
     <Login />
      <Link to="/">메세지</Link>
      <Link to="/about">주소록</Link>
    </div>
  );
};

export default NavBar;
