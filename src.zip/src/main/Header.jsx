import React from 'react';
import {Link} from 'react-router-dom'
import './Header.css';

const Header = (props) => {
  return (
    <header id="header" className={props.attr} role="heading" aria-level="1">
      <div className="header__inner container">
        <div className="header_logo">
      <Link to="/">
      PickMiji
          </Link>
          </div>
        <div className="header__nav" role="navigation">
          <ul className='main_ul'>
            <li>
              <Link to="/text">메세지</Link>
            </li>
            <li>
              <Link to="/text">주소록</Link>
            </li>
            </ul>
        </div>
        <div className="header_login">
              <Link to="/login">로그인</Link>
        </div>
      </div>
    </header>
  );
};

export default Header;

