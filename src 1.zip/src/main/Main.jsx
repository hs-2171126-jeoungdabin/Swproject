// src/Main.jsx
import React from 'react';
import NavBar from './components/NavBar';
import Text from './components/Text';

const Main = () => {
  return (
    <contents>
      
    
      <Text attr='Text__wrap'/>
    
    </contents>
  );
};

export default Main;
